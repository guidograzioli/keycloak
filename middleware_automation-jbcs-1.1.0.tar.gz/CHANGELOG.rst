========================================
middleware_automation.jbcs Release Notes
========================================

.. contents:: Topics

This changelog describes changes after version 1.0.0.

v1.0.3
======

Minor Changes
-------------

- Add comprehensive molecule test `#2 <https://github.com/ansible-middleware/jbcs/pull/2>`_
- Add firewalld configuration flag `#1 <https://github.com/ansible-middleware/jbcs/pull/1>`_

v1.0.2
======

v1.0.1
======

v1.0.0
======
