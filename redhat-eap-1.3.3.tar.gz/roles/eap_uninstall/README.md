eap uninstall role
======================

Role to uninstall and clean eap from ansible nodes.

<!--start argument_specs-->
Role Defaults
-------------

* No defaults

Role Variables
--------------

* No required variables
<!--end argument_specs-->
