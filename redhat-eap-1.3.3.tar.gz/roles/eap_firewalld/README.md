eap firewalld role
======================

Install and configure the firewalld service for eap application server or JBoss Enterprise Application (EAP)
