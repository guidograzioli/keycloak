eap prospero role
=====================

Integrate Prospero as an alternative installation mechanism for Wildfly
