eap validation role
=======================

Role to validate that the app server installed was successful
and the associated systemd service is currently running.

<!--start argument_specs-->
Role Defaults
-------------

| Variable | Description | Default |
|:---------|:------------|:--------|
|`eap_user`| posix user account for eap | `eap` |
|`eap_group`| posix group for eap | `{{ eap_user }}` |
|`eap_service_name`| Systemd service name for eap | `eap` |

Role Variables
--------------

* No required variables
<!--end argument_specs-->
