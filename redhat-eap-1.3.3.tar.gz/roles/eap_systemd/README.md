eap systemd role
====================

Role setting up a systemd service to manage a Wildfly app server instance, using basic information on server installation.

Note: default values are based on the one of the eap_install role.

Requirements
------------

A working systemd environment is required on target's system.

<!--start argument_specs-->
Role Defaults
-------------

| Variable | Description | Default |
|:---------|:------------|:--------|
|`eap_user`| posix user account for eap service | `eap` |
|`eap_group`| posix group for eap service | `{{ eap_user }}` |
|`eap_version`| Wildfly version to install | `27.0.0.Final` |
|`eap_install_workdir`| TODO document argument | `/opt/eap/` |
|`eap_home`| Wildfly installation directory | `{{ eap_install_workdir }}eap-{{ eap_version }}/` |
|`eap_config_base`| Base standalone.xml config for instance | `standalone.xml` unless `eap_config_custom_file` is used |
|`eap_config_custom_file`| Custom standalone.xml config to be copied to target instance and used as base | `''` |
|`eap_port_range_offset`| Increment for `jboss.socket.binding.port-offset` | `100` |
|`eap_systemd_unit_enabled`| Enable systemd unit to autostart after reboot | `True` |
|`eap_systemd_service_config_location`| Path for systemd unit file | `/usr/lib/systemd/system` |
|`eap_systemd_service_config_file_suffix`| Systemd unit file extension | `.service` |
|`eap_systemd_conf_file_suffix`| Suffix for systemd conf file | `.conf` |
|`eap_systemd_service_config_file_template`| Template for systemd unit | `templates/wfly.service.j2` |
|`eap_service_config_file_template`| Template for systemd config | `templates/wfly.conf.j2` |
|`eap_service_config_file_location`| Path for eap systemd unit file | `/etc/` |
|`eap_enable_yml_config`| Enable yaml file configuration feature (WFCORE5343) | `False` |
|`eap_yml_configs`| List of filenames for eap configuration bootstrap | `[]` |
|`eap_java_package_name`| RHEL java rpm package | `java-11-openjdk-headless` |
|`eap_java_opts`| Additional settings for the JVM running eap | `-Xmx1024M -Xms512M` |
|`eap_bind_addr`| Bind address for listening to public network | `0.0.0.0` |
|`eap_bind_addr_private`| Bind address for listening to private network |`127.0.0.1` |
|`eap_bind_addr_management`| Bind address for management console port |`127.0.0.1` |
|`eap_multicast_addr`| Multicast address for jgroup cluster discovery |`230.0.0.4` |
|`eap_statistics_enabled`| Whether to enable statistics | `False` |

Role Variables
--------------

| Variable | Description | Required |
|:---------|:------------|:---------|
|`eap_java_home`| JAVA_HOME of installed JRE, leave empty for using specified eap_java_package_name RPM path | `No` |
|`eap_instance_id`| When collocating services on the same host, EAP instance ID (integer value) | `No` |
|`eap_instance_name`| When collocating services on the same host, EAP instance name | `No` |
<!--end argument_specs-->

Dependencies
------------

Example Playbook
----------------

```
  tasks:

    - name: "Set up for WildFly instance {{ item }}"
      include_role:
        name: eap_systemd
      vars:
        eap_config_base: 'standalone-ha.xml'
        eap_basedir_prefix: "/opt/{{ inventory_hostname }}"
        eap_config_name: "{{ install_name }}"
        eap_port_range_offset: 100
        eap_instance_name: "{{ install_name }}"
        eap_instance_id: "{{ item }}"
        service_systemd_env_file: "/etc/eap-{{ item }}.conf"
        service_systemd_conf_file: "/usr/lib/systemd/system/jboss-eap-{{ item }}.service"
      loop: "{{ range(0,3) | list }}"
```


License
-------

GPL2


Author Information
------------------

* [Romain Pelisse](https://github.com/rpelisse)
