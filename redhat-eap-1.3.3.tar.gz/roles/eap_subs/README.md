eap subs role
====================

This role is designed to help set up JBoss EAP (Red Hat product based on Wildfly) using RPM
delivered by Red Hat to its customer. The playbook provides handy reusable content to enable
or disable a repo and install EAP using the group install feature.

Requirements
------------

Requirements on the target system are ensured by the role.

<!--start argument_specs-->
Role Defaults
-------------

| Variable | Description | Default |
|:---------|:------------|:--------|
|`eap_subs_check_repo_enable`| Enable repo | ` True`
|`eap_subs_check_repo_disabled`| Disable repo | ` "{{ eap_subs_check_repo_enable }}"`
|`eap_subs_skip_remove`| Remove installed server | ` False`
|`eap_repos_state_file_homedir`| State file home directory | ` /opt`
|`eap_repos_state_file_prefix`| State filename prefix | ` .eap`
|`eap_repos_state_file_suffix`| State filename suffix | ` .repo`
|`eap_rpm_install_root_dir`| RPM install root dir | ` /opt/rh/eap7/`
|`eap_group_install_name`| EAP group install package name| ` jboss-eap7-jdk11`

Role Variables
--------------

* No required variables

<!--end argument_specs-->

## Dependencies

## Example Playbooks

### Enable repository


TODO

## License

GPL2

## Author Information

* [Romain Pelisse](https://github.com/rpelisse)
