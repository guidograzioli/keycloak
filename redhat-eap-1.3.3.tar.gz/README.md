# Wildfly Collection for Ansible - redhat.eap



## About

This Ansible Collection provides several roles to help install, setup and maintain Java JEE appserver Wildfly within the configuration management tool Ansible.

### I know nothing about Ansible, but I want to install Wildfly, can I?

Yes, once Ansible is installed on your computer, you can simply run the following command (note that the inventory file needs to be populated with the name(s) of the machine(s) you wish to install Wildfly on):

    $ ansible-galaxy collection install redhat.eap
    $ ansible-playbook -i inventory redhat.eap.playbook

<!--start requires_ansible-->
## Ansible version compatibility

This collection has been tested against following Ansible versions: **>=2.9.10**.


## Install

Plugins and modules within a collection may be tested with only specific Ansible versions. A collection may contain metadata that identifies these versions.
<!--end requires_ansible-->

## Included content

### Roles

* [eap_install](content/role/eap_install/README.md): download and install
* [eap_systemd](content/role/eap_systemd/README.md): configure systemd unit
* [eap_driver](content/role/eap_driver/README.md): install additional driver modules (ie. JDBC)
* [eap_utils](content/role/eap_utils/README.md): utilities related to EAP
* [eap_validation](content/role/eap_validation/README.md): validate deployed installation
* [eap_uninstall](content/role/eap_uninstall/README.md): restore status pre eap_install


### Installing the collection

To install this Ansible collection:

    $ ansible-galaxy collection install redhat.eap

or with a downloaded or built tarball, run the following command:

    $ ansible-galaxy collection install /path/to/redhat.eap.tgz

or via the included requirements file:

    $ ansible-galaxy collection install -r requirements.yml


## Building the collection

    $ ansible-galaxy collection build .


### Dependencies

* [redhat.runtimes_common](https://github.com/ansible-middleware/common)
* [ansible-posix](https://docs.ansible.com/ansible/latest/collections/ansible/posix/index.html)


## Support

redhat.eap collection v1.3.3 is for [Technical Preview](https://access.redhat.com/support/offerings/techpreview).
If you have any issues or questions related to collection, please don't hesitate to contact us on <Ansible-middleware-core@redhat.com> or open an issue on
<https://github.com/ansible-middleware/keycloak/issues>



## License

[GNU General Public License v2.0](https://github.com/ansible-middleware/eap/blob/main/LICENSE)
