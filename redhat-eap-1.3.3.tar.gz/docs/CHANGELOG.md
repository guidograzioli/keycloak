# redhat.eap Release Notes

Topics

This changelog describes changes after version 0.0.7.

## v1.3.3

### Minor Changes

-   Check that systemd is running and pidfile exists
    [#117](https://github.com/ansible-middleware/wildfly/pull/117)
-   elytron\_adapter: skip download if file is already present
    [#120](https://github.com/ansible-middleware/wildfly/pull/120)
-   eap\_systemd: accept same default vars as eap\_install
    [#111](https://github.com/ansible-middleware/wildfly/pull/111)

### Bugfixes

-   '.Beta' in version: the dot is only optional
    [#119](https://github.com/ansible-middleware/wildfly/pull/119)
-   ISSUE116 - PID File Creation Failure
    [#118](https://github.com/ansible-middleware/wildfly/pull/118)

## v1.3.2

### Minor Changes

-   Add check for offline installs and allow to specify custom xml
    config [#108](https://github.com/ansible-middleware/wildfly/pull/108)
-   Add support for firewalld
    [#106](https://github.com/ansible-middleware/wildfly/pull/106)
-   Implement JBossNetwork API client for downloading install archives
    [#107](https://github.com/ansible-middleware/wildfly/pull/107)
-   Install: add prospero as alternative install mechanism
    [#102](https://github.com/ansible-middleware/wildfly/pull/102)
-   Update default Wildfly version to 28
    [#103](https://github.com/ansible-middleware/wildfly/pull/103)

## v1.3.1

### Minor Changes

-   Remove dependency to community.general (not required)
    [#100](https://github.com/ansible-middleware/wildfly/pull/100)

## v1.3.0

### Minor Changes

-   Apply cp options
    [#99](https://github.com/ansible-middleware/wildfly/pull/99)

## v1.2.2

### Major Changes

-   eap\_install: (eap) apply\_cp does not depend on systemd
    [#90](https://github.com/ansible-middleware/wildfly/pull/90)

### Minor Changes

-   Add elytron adapter install (EAP)
    [#92](https://github.com/ansible-middleware/wildfly/pull/92)
-   eap-systemd: yaml configuration extension accept templates
    [#91](https://github.com/ansible-middleware/wildfly/pull/91)

### Bugfixes

-   Correctly handle server restarts post apply\_cp and
    keycloak\_adapter
    [#94](https://github.com/ansible-middleware/wildfly/pull/94)

## v1.2.1

### Release Summary

Patch release with internal changes only.

## v1.2.0

### Major Changes

-   Propagate eap\_install defaults to driver, systemd and utils roles
    [#80](https://github.com/ansible-middleware/wildfly/pull/80)

### Bugfixes

-   Become in "Check local download archive path"
    [#74](https://github.com/ansible-middleware/wildfly/pull/74)
-   eap\_driver: added eap\_user and eap\_group to defaults
    [#77](https://github.com/ansible-middleware/wildfly/pull/77)

## v1.1.0

### Minor Changes

-   Bump version to 1.1.0 to align with downstream (1.1.0 is identical
    to 1.0.6 upstream)
    [#67](https://github.com/ansible-middleware/wildfly/pull/67)

## v1.0.6

## v1.0.5

### Minor Changes

-   Add `eap_java_opts` to set parameters for wfly JVM
    [#60](https://github.com/ansible-middleware/wildfly/pull/60)
-   Add `eap_statistics_enabled` var to enable statistics
    [#58](https://github.com/ansible-middleware/wildfly/pull/58)
-   Add variable `eap_bind_addr_private` to set private iface bind
    address [#55](https://github.com/ansible-middleware/wildfly/pull/55)
-   Add variable `eap_multicast_addr` to set tcp/udp mcast address
    [#56](https://github.com/ansible-middleware/wildfly/pull/56)
-   Added variable for setting management port bind address
    [#62](https://github.com/ansible-middleware/wildfly/pull/62)

### Bugfixes

-   Fix EAP patch apply when yaml configuration is enabled
    [#59](https://github.com/ansible-middleware/wildfly/pull/59)

## v1.0.4

### Breaking Changes / Porting Guide

-   Rename variable `instance_id` to `eap_instance_id` and update docs
    [#52](https://github.com/ansible-middleware/wildfly/pull/52)

### Bugfixes

-   Add become parameter to tasks that require it
    [#53](https://github.com/ansible-middleware/wildfly/pull/53)

## v1.0.3

### Minor Changes

-   Rename validation role vars to follow proper convention
    [#48](https://github.com/ansible-middleware/wildfly/pull/48)
-   eap\_driver: make variables as default
    [#39](https://github.com/ansible-middleware/wildfly/pull/39)

### Breaking Changes / Porting Guide

-   Rename jboss\_eap role into eap\_utils to be consistent with role
    naming convention
    [#45](https://github.com/ansible-middleware/wildfly/pull/45)

### Bugfixes

-   JAVA\_HOME should be set according to requested JVM package, or
    overridden via `eap_java_home`
    [#46](https://github.com/ansible-middleware/wildfly/pull/46)
-   Update included role to new name in rhn installation
    [#51](https://github.com/ansible-middleware/wildfly/pull/51)

## v1.0.2

### Release Summary

Minor enhancements, and documentation updates.

## v1.0.1

### Release Summary

Minor enhancements, and documentation updates.

## v1.0.0

### Release Summary

This is the first stable release of the `redhat.eap` collection.
