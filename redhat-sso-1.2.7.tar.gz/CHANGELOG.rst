============================================
redhat.sso Release Notes
============================================

.. contents:: Topics

This changelog describes changes after version 0.2.6.

v1.2.6
======

Minor Changes
-------------

- Add profile features enabling/disabling `#87 <https://github.com/ansible-middleware/sso/pull/87>`_
- Improve service restart behavior configuration `#88 <https://github.com/ansible-middleware/sso/pull/88>`_
- Update default xa_datasource_class value for mariadb jdbc configuration `#89 <https://github.com/ansible-middleware/sso/pull/89>`_

Bugfixes
--------

- Handle WFLYCTL0117 when background validation millis is 0 `#90 <https://github.com/ansible-middleware/sso/pull/90>`_

v1.2.5
======

Minor Changes
-------------

- Add configuration for database connection pool validation `#85 <https://github.com/ansible-middleware/sso/pull/85>`_
- Allow to configure administration endpoint URL `#86 <https://github.com/ansible-middleware/sso/pull/86>`_
- Allow to force backend URLs to frontend URLs `#84 <https://github.com/ansible-middleware/sso/pull/84>`_
- Introduce systemd unit restart behavior `#81 <https://github.com/ansible-middleware/sso/pull/81>`_

v1.2.4
======

Minor Changes
-------------

- Add ``sqlserver`` to sso role jdbc configurations `#78 <https://github.com/ansible-middleware/sso/pull/78>`_
- Add configurability for XA transactions `#73 <https://github.com/ansible-middleware/sso/pull/73>`_

Bugfixes
--------

- Fix deprecation warning for ``ipaddr`` `#77 <https://github.com/ansible-middleware/sso/pull/77>`_
- Fix undefined facts when offline patching sso `#71 <https://github.com/ansible-middleware/sso/pull/71>`_

v1.2.1
======

Minor Changes
-------------

- Allow to setup sso HA cluster without remote cache store `#68 <https://github.com/ansible-middleware/sso/pull/68>`_

Bugfixes
--------

- Pass attributes to realm clients `#69 <https://github.com/ansible-middleware/sso/pull/69>`_

v1.2.0
======

Major Changes
-------------

- Provide config for multiple modcluster proxies `#60 <https://github.com/ansible-middleware/sso/pull/60>`_

Minor Changes
-------------

- Allow to configure TCPPING for cluster discovery `#62 <https://github.com/ansible-middleware/sso/pull/62>`_
- Drop community.general from dependencies `#61 <https://github.com/ansible-middleware/sso/pull/61>`_
- Switch redhat.redhat_csp_download for redhat.runtimes_common `#63 <https://github.com/ansible-middleware/sso/pull/63>`_
- Switch to redhat.runtimes_common for rh-sso patching `#64 <https://github.com/ansible-middleware/sso/pull/64>`_

v1.1.1
======

Bugfixes
--------

- sso-quarkus: fix ``cache-config-file`` path in sso.conf.j2 template `#53 <https://github.com/ansible-middleware/sso/pull/53>`_

v1.1.0
======

Minor Changes
-------------

- Update sso to 18.0.2 - sso to 7.6.1 `#46 <https://github.com/ansible-middleware/sso/pull/46>`_
- Variable ``sso_no_log`` controls ansible ``no_log`` parameter (for debugging purposes) `#47 <https://github.com/ansible-middleware/sso/pull/47>`_
- Variables to override service start retries and delay `#51 <https://github.com/ansible-middleware/sso/pull/51>`_
- sso_quarkus: variable to enable development mode `#45 <https://github.com/ansible-middleware/sso/pull/45>`_

Breaking Changes / Porting Guide
--------------------------------

- Rename variables from ``infinispan_`` prefix to ``sso_infinispan_`` `#42 <https://github.com/ansible-middleware/sso/pull/42>`_

Bugfixes
--------

- sso_quarkus: fix /var/log/sso symlink to sso log directory `#44 <https://github.com/ansible-middleware/sso/pull/44>`_

v1.0.7
======

Breaking Changes / Porting Guide
--------------------------------

- sso_quarkus: use absolute path for certificate files `#39 <https://github.com/ansible-middleware/sso/pull/39>`_

Bugfixes
--------

- sso_quarkus: use become for tasks that will otherwise fail `#38 <https://github.com/ansible-middleware/sso/pull/38>`_

v1.0.6
======

Bugfixes
--------

- sso_quarkus: add selected java to PATH in systemd unit `#34 <https://github.com/ansible-middleware/sso/pull/34>`_
- sso_quarkus: set logfile path correctly under sso home `#35 <https://github.com/ansible-middleware/sso/pull/35>`_

v1.0.5
======

Minor Changes
-------------

- Update config options: sso and quarkus `#32 <https://github.com/ansible-middleware/sso/pull/32>`_

v1.0.4
======

v1.0.3
======

Major Changes
-------------

- New role for installing sso >= 17.0.0 (quarkus) `#29 <https://github.com/ansible-middleware/sso/pull/29>`_

Minor Changes
-------------

- Add ``sso_config_override_template`` parameter for passing a custom xml config template `#30 <https://github.com/ansible-middleware/sso/pull/30>`_

Bugfixes
--------

- Make sure systemd unit starts with selected java JVM `#31 <https://github.com/ansible-middleware/sso/pull/31>`_

v1.0.2
======

Minor Changes
-------------

- Make ``sso_admin_password`` a default with assert (was: role variable) `#26 <https://github.com/ansible-middleware/sso/pull/26>`_
- Simplify dependency install logic and reduce play execution time `#19 <https://github.com/ansible-middleware/sso/pull/19>`_

Bugfixes
--------

- Set ``sso_frontend_url`` default according to other defaults `#25 <https://github.com/ansible-middleware/sso/pull/25>`_

v1.0.1
======

Release Summary
---------------

Minor enhancements, bug and documentation fixes.


Major Changes
-------------

- Apply latest cumulative patch of RH-SSO automatically when new parameter ``sso_rhsso_apply_patches`` is ``true`` `#18 <https://github.com/ansible-middleware/sso/pull/18>`_

Minor Changes
-------------

- Clustered installs now perform database initialization on first node to avoid locking issues `#17 <https://github.com/ansible-middleware/sso/pull/17>`_

v1.0.0
======

Release Summary
---------------

This is the first stable release of the ``redhat.sso`` collection.

