sso_realm
==============

Create realms and clients in [sso](https://keycloak.org/) or [Red Hat Single Sign-On](https://access.redhat.com/products/red-hat-single-sign-on) services.


Role Defaults
-------------

| Variable | Description | Default |
|:---------|:------------|:--------|
|`sso_admin_user`| Administration console user account | `admin` |
|`sso_host`| hostname | `localhost` |
|`sso_context`| Context path for rest calls | `/auth` |
|`sso_http_port`| HTTP port | `8080` |
|`sso_https_port`| TLS HTTP port | `8443` |
|`sso_auth_realm`| Name of the main authentication realm | `master` |
|`sso_management_http_port`| Management port | `9990` |
|`sso_auth_client`| Authentication client for configuration REST calls | `admin-cli` |
|`sso_client_public`| Configure a public realm client | `True` |
|`sso_client_web_origins`| Web origins for realm client | `+` |
|`sso_url`| URL for configuration rest calls | `http://{{ sso_host }}:{{ sso_http_port }}` |
|`sso_management_url`| URL for management console rest calls | `http://{{ sso_host }}:{{ sso_management_http_port }}` |


Role Variables
--------------

The following are a set of _required_ variables for the role:

| Variable | Description |
|:---------|:------------|
|`sso_realm` | Name of the realm to be created |
|`sso_admin_password`| Password for the administration console user account |


The following variables are available for creating clients:

| Variable | Description | Default |
|:---------|:------------|:---------|
|`sso_clients` | List of _client_ declarations for the realm | `[]` |
|`sso_client_default_roles` | List of default role name for clients | `[]` |
|`sso_client_users` | List of user/role mappings for a client | `[]` |


The following variable are available for creating user federation:

| Variable | Description | Default |
|:---------|:------------|:---------|
|`sso_user_federation` | List of _sso_user_federation_ for the realm | `[]` |


Variable formats
----------------

* `sso_user_federation`, a list of:

```yaml
    - realm:  <name of the realm in which user federation should be configured, required>
      name: <name of the user federation provider, required>
      provider_id: <type of the user federation provider, required>
      provider_type: <Provider Type, default is set to org.keycloak.storage.UserStorageProvider>
      config: <dictionary of supported configuration values, required>
      mappers: <list of supported configuration values, required>
```

Refer to [docs](https://docs.ansible.com/ansible/latest/collections/community/general/sso_user_federation_module.html) for information on supported variables.


* `sso_clients`, a list of:

```yaml
    - name: <name of the client>
      id: <id of the client>
      client_id: <id of the client>
      roles: <sso_client_default_roles>
      realm: <name of the realm that contains the client>
      public_client: <true for public, false for confidential>
      web_origins: <list of allowed we origins for the client>
      users: <sso_client_users>
```

`name` and either `id` or `client_id` are required.


* `sso_client_users`, a list of:

```yaml
    - username: <username, required>
      password: <password, required>
      firstName: <firstName, optional>
      lastName: <lastName, optional>
      email: <email, optional>
      client_roles: <list of client user/role mappings>
```

* Client user/role mappings, a list of:

```yaml
    - client: <name of the client>
      role: <name of the role>
      realm: <name of the realm>
```

For a comprehensive example, refer to the [playbook](../../playbooks/sso_realm.yml).


Example Playbook
----------------

The following is an example playbook that makes use of the role to create a realm in sso.

```yaml
---
- hosts: ...
      collections:
        - redhat.sso
      tasks:
        - name: Include sso role
          include_role:
            name: sso_realm
          vars:
            sso_admin_password: "changeme"
            sso_realm: TestRealm
            sso_clients: [...]
```


License
-------

Apache License 2.0


Author Information
------------------

* [Guido Grazioli](https://github.com/guidograzioli)
* [Romain Pelisse](https://github.com/rpelisse)