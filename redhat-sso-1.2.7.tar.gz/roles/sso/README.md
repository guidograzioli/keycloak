sso
========

Install [sso](https://keycloak.org/) or [Red Hat Single Sign-On](https://access.redhat.com/products/red-hat-single-sign-on) server configurations.


Requirements
------------

This role requires the `python3-netaddr` library installed on the controller node.

* to install via yum/dnf: `dnf install python3-netaddr`
* or via pip: `pip install netaddr==0.8.0`
* or via the collection: `pip install -r requirements.txt`


Dependencies
------------

The roles depends on:

* [redhat.runtimes_common](https://github.com/ansible-middleware/common)
* [ansible-posix](https://docs.ansible.com/ansible/latest/collections/ansible/posix/index.html)

To install all the dependencies via galaxy:

    ansible-galaxy collection install -r requirements.yml


Versions
--------

| RH-SSO VERSION | Release Date      | Keycloak Version | EAP Version | Notes           |
|:---------------|:------------------|:-----------------|:------------|:----------------|
|`7.5.0 GA`      |September 20, 2021 |`15.0.2`          | `7.4.6`     |[Release Notes](https://access.redhat.com/documentation/en-us/red_hat_single_sign-on/7.5/html/release_notes/index)|
|`7.6.0 GA`      |June 30, 2022      |`18.0.3`          | `7.4.6`     |[Release Notes](https://access.redhat.com/documentation/en-us/red_hat_single_sign-on/7.6/html-single/release_notes/index)|


Patching
--------

When variable `sso_rhsso_apply_patches` is `True` (default: `False`), the role will automatically apply the latest cumulative patch for the selected base version.

| RH-SSO VERSION | Release Date      | RH-SSO LATEST CP | Notes           |
|:---------------|:------------------|:-----------------|:----------------|
|`7.5.0 GA`      |January 20, 2022   |`7.5.3 GA`        |[Release Notes](https://access.redhat.com/articles/6646321)|
|`7.6.0 GA`      |November 11, 2022  |`7.6.1 GA`        |[Release Notes](https://access.redhat.com/articles/6982711)|


Role Defaults
-------------

* Service configuration

| Variable | Description | Default |
|:---------|:------------|:---------|
|`sso_ha_enabled`| Enable auto configuration for database backend, clustering and remote caches on infinispan | `False` |
|`sso_ha_discovery`| Discovery protocol for HA cluster members | `JDBC_PING` if sso_db_enabled else `TCPPING` |
|`sso_db_enabled`| Enable auto configuration for database backend | `True` if `sso_ha_enabled` is True, else `False` |
|`sso_remote_cache_enabled`| Enable remote cache store when in clustered ha configurations | `True` if `sso_ha_enabled` else `False` |
|`sso_admin_user`| Administration console user account | `admin` |
|`sso_bind_address`| Address for binding service ports | `0.0.0.0` |
|`sso_management_port_bind_address`| Address for binding management ports | `127.0.0.1` |
|`sso_host`| hostname | `localhost` |
|`sso_http_port`| HTTP port | `8080` |
|`sso_https_port`| TLS HTTP port | `8443` |
|`sso_ajp_port`| AJP port | `8009` |
|`sso_jgroups_port`| jgroups cluster tcp port | `7600` |
|`sso_management_http_port`| Management port | `9990` |
|`sso_management_https_port`| TLS management port | `9993` |
|`sso_prefer_ipv4`| Prefer IPv4 stack and addresses for port binding | `True` |
|`sso_config_standalone_xml`| filename for configuration | `sso.xml` |
|`sso_service_user`| posix account username | `sso` |
|`sso_service_group`| posix account group | `sso` |
|`sso_service_restart_always`| systemd restart always behavior activation | `False`
|`sso_service_restart_on_failure`| systemd restart on-failure behavior activation | `False`
|`sso_service_startlimitintervalsec`| systemd StartLimitIntervalSec | `300` |
|`sso_service_startlimitburst`| systemd StartLimitBurst | `5` |
|`sso_service_restartsec`| systemd RestartSec | `10s` |
|`sso_service_pidfile`| pid file path for service | `/run/sso.pid` |
|`sso_features` | List of `name`/`status` pairs of features (also known as profiles on RH-SSO) to `enable` or `disable`, example: `[ { name: 'docker', status: 'enabled' } ]` | `[]`
|`sso_jvm_package`| RHEL java package runtime | `java-1.8.0-openjdk-headless` |
|`sso_java_home`| JAVA_HOME of installed JRE, leave empty for using specified sso_jvm_package RPM path | `None` |
|`sso_java_opts`| Additional JVM options | `-Xms1024m -Xmx2048m` |


* Install options

| Variable | Description | Default |
|:---------|:------------|:---------|
|`sso_offline_install` | perform an offline install | `False`|
|`sso_download_url`| Download URL for sso | `https://github.com/sso/sso/releases/download/<version>/<archive>`|
|`sso_version`| keycloak.org package version | `18.0.2` |
|`sso_dest`| Installation root path | `/opt/sso` |
|`sso_download_url` | Download URL for sso | `https://github.com/sso/sso/releases/download/{{ sso_version }}/{{ sso_archive }}` |
|`sso_configure_firewalld` | Ensure firewalld is running and configure sso ports | `False` |


* Miscellaneous configuration

| Variable | Description | Default |
|:---------|:------------|:--------|
|`sso_archive` | sso install archive filename | `sso-legacy-{{ sso_version }}.zip` |
|`sso_download_url_9x` | Download URL for sso (deprecated) | `https://downloads.jboss.org/sso/{{ sso_version }}/{{ sso_archive }}` |
|`sso_installdir` | Installation path | `{{ sso_dest }}/sso-{{ sso_version }}` |
|`sso_jboss_home` | Installation work directory | `{{ sso_rhsso_installdir }}` |
|`sso_config_dir` | Path for configuration | `{{ sso_jboss_home }}/standalone/configuration` |
|`sso_config_path_to_standalone_xml` | Custom path for configuration | `{{ sso_jboss_home }}/standalone/configuration/{{ sso_config_standalone_xml }}` |
|`sso_config_override_template` | Path to custom template for standalone.xml configuration | `''` |
|`sso_auth_realm` | Name for rest authentication realm | `master` |
|`sso_auth_client` | Authentication client for configuration REST calls | `admin-cli` |
|`sso_force_install` | Remove pre-existing versions of service | `False` |
|`sso_url` | URL for configuration rest calls | `http://{{ sso_host }}:{{ sso_http_port }}` |
|`sso_management_url` | URL for management console rest calls | `http://{{ sso_host }}:{{ sso_management_http_port }}` |
|`sso_frontend_url_force` | Force backend requests to use the frontend URL | `False` |
|`sso_db_background_validation` | Enable background validation of database connection | `False` |
|`sso_db_background_validation_millis`| How frequenly the connection pool is validated in the background | `10000` if background validation enabled |
|`sso_db_background_validate_on_match` | Enable validate on match for database connections | `False` |
|`sso_frontend_url` | frontend URL for sso endpoint | `http://localhost:8080/auth/` |



Role Variables
--------------

The following are a set of _required_ variables for the role:

| Variable | Description |
|:---------|:------------|
|`sso_admin_password`| Password for the administration console user account (minimum 12 characters) |
|`sso_frontend_url` | frontend URL for sso endpoint | `http://localhost:8080/auth/` |


The following parameters are _required_ only when `sso_ha_enabled` is True:

| Variable | Description | Default |
|:---------|:------------|:--------|
|`sso_modcluster_enabled`| Enable configuration for modcluster subsystem | `True` if `sso_ha_enabled` is True, else `False` |
|`sso_modcluster_url` | _deprecated_ Host for the modcluster reverse proxy | `localhost` |
|`sso_modcluster_port` | _deprecated_ Port for the modcluster reverse proxy | `6666` |
|`sso_modcluster_urls` | List of {host,port} dicts for the modcluster reverse proxies | `[ { localhost:6666 } ]` |
|`sso_jdbc_engine` | backend database engine when db is enabled: [ postgres, mariadb, sqlserver ] | `postgres` |
|`sso_infinispan_url` | URL for the infinispan remote-cache server | `localhost:11122` |
|`sso_infinispan_user` | username for connecting to infinispan | `supervisor` |
|`sso_infinispan_pass` | password for connecting to infinispan | `supervisor` |
|`sso_infinispan_sasl_mechanism`| Authentication type | `SCRAM-SHA-512` |
|`sso_infinispan_use_ssl`| Enable hotrod TLS communication | `False` |
|`sso_infinispan_trust_store_path`| Path to truststore with infinispan server certificate | `/etc/pki/java/cacerts` |
|`sso_infinispan_trust_store_password`| Password for opening truststore | `changeit` |


The following parameters are _required_ only when `sso_db_enabled` is True:

| Variable | Description | Default |
|:---------|:------------|:---------|
|`sso_jdbc_url` | URL for the postgres backend database | `jdbc:postgresql://localhost:5432/sso` |
|`sso_jdbc_driver_version`| Version for the JDBC driver to download | `9.4.1212` |
|`sso_db_user` | username for connecting to postgres | `sso-user` |
|`sso_db_pass` | password for connecting to postgres | `sso-pass` |


The following variables are _optional_:

| Variable | Description |
|:---------|:------------|
|`sso_db_valid_conn_sql` | Override the default database connection validation query sql |
|`sso_admin_url` | Override the default administration endpoint URL |
|`sso_jgroups_subnet`| Override the subnet match for jgroups cluster formation; if not defined, it will be inferred from local machine route configuration |

Example Playbook
-----------------

* The following is an example playbook that makes use of the role to install sso from remote:

```yaml
---
- hosts: ...
      vars:
        sso_admin_password: "remembertochangeme"
      roles:
        - redhat.sso.sso
```


* The following example playbook makes use of the role to install sso from the controller node:

```yaml
---
- hosts: ...
      collections:
        - redhat.sso
      tasks:
        - name: Include sso role
          include_role:
            name: sso
          vars:
            sso_admin_password: "remembertochangeme"
            sso_offline_install: True
            # This should be the filename of sso archive on Ansible node: sso-16.1.0.zip
```

License
-------

Apache License 2.0


Author Information
------------------

* [Guido Grazioli](https://github.com/guidograzioli)
* [Romain Pelisse](https://github.com/rpelisse)
* [Pavan Kumar Motaparthi](https://github.com/motaparthipavankumar)
