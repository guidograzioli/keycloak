# redhat.sso Release Notes

Topics

This changelog describes changes after version 0.2.6.

## v1.2.6

### Minor Changes

-   Add profile features enabling/disabling
    [#87](https://github.com/ansible-middleware/keycloak/pull/87)
-   Improve service restart behavior configuration
    [#88](https://github.com/ansible-middleware/keycloak/pull/88)
-   Update default xa\_datasource\_class value for mariadb jdbc
    configuration
    [#89](https://github.com/ansible-middleware/keycloak/pull/89)

### Bugfixes

-   Handle WFLYCTL0117 when background validation millis is 0
    [#90](https://github.com/ansible-middleware/keycloak/pull/90)

## v1.2.5

### Minor Changes

-   Add configuration for database connection pool validation
    [#85](https://github.com/ansible-middleware/keycloak/pull/85)
-   Allow to configure administration endpoint URL
    [#86](https://github.com/ansible-middleware/keycloak/pull/86)
-   Allow to force backend URLs to frontend URLs
    [#84](https://github.com/ansible-middleware/keycloak/pull/84)
-   Introduce systemd unit restart behavior
    [#81](https://github.com/ansible-middleware/keycloak/pull/81)

## v1.2.4

### Minor Changes

-   Add `sqlserver` to sso role jdbc configurations
    [#78](https://github.com/ansible-middleware/keycloak/pull/78)
-   Add configurability for XA transactions
    [#73](https://github.com/ansible-middleware/keycloak/pull/73)

### Bugfixes

-   Fix deprecation warning for `ipaddr`
    [#77](https://github.com/ansible-middleware/keycloak/pull/77)
-   Fix undefined facts when offline patching sso
    [#71](https://github.com/ansible-middleware/keycloak/pull/71)

## v1.2.1

### Minor Changes

-   Allow to setup sso HA cluster without remote cache store
    [#68](https://github.com/ansible-middleware/keycloak/pull/68)

### Bugfixes

-   Pass attributes to realm clients
    [#69](https://github.com/ansible-middleware/keycloak/pull/69)

## v1.2.0

### Major Changes

-   Provide config for multiple modcluster proxies
    [#60](https://github.com/ansible-middleware/keycloak/pull/60)

### Minor Changes

-   Allow to configure TCPPING for cluster discovery
    [#62](https://github.com/ansible-middleware/keycloak/pull/62)
-   Drop community.general from dependencies
    [#61](https://github.com/ansible-middleware/keycloak/pull/61)
-   Switch redhat.redhat\_csp\_download for redhat.runtimes\_common
    [#63](https://github.com/ansible-middleware/keycloak/pull/63)
-   Switch to redhat.runtimes\_common for rh-sso patching
    [#64](https://github.com/ansible-middleware/keycloak/pull/64)

## v1.1.1

### Bugfixes

-   sso-quarkus: fix `cache-config-file` path in sso.conf.j2 template
    [#53](https://github.com/ansible-middleware/keycloak/pull/53)

## v1.1.0

### Minor Changes

-   Update sso to 18.0.2 - sso to 7.6.1
    [#46](https://github.com/ansible-middleware/keycloak/pull/46)
-   Variable `sso_no_log` controls ansible `no_log` parameter (for
    debugging purposes)
    [#47](https://github.com/ansible-middleware/keycloak/pull/47)
-   Variables to override service start retries and delay
    [#51](https://github.com/ansible-middleware/keycloak/pull/51)
-   sso\_quarkus: variable to enable development mode
    [#45](https://github.com/ansible-middleware/keycloak/pull/45)

### Breaking Changes / Porting Guide

-   Rename variables from `infinispan_` prefix to `sso_infinispan_`
    [#42](https://github.com/ansible-middleware/keycloak/pull/42)

### Bugfixes

-   sso\_quarkus: fix /var/log/sso symlink to sso log directory
    [#44](https://github.com/ansible-middleware/keycloak/pull/44)

## v1.0.7

### Breaking Changes / Porting Guide

-   sso\_quarkus: use absolute path for certificate files
    [#39](https://github.com/ansible-middleware/keycloak/pull/39)

### Bugfixes

-   sso\_quarkus: use become for tasks that will otherwise fail
    [#38](https://github.com/ansible-middleware/keycloak/pull/38)

## v1.0.6

### Bugfixes

-   sso\_quarkus: add selected java to PATH in systemd unit
    [#34](https://github.com/ansible-middleware/keycloak/pull/34)
-   sso\_quarkus: set logfile path correctly under sso home
    [#35](https://github.com/ansible-middleware/keycloak/pull/35)

## v1.0.5

### Minor Changes

-   Update config options: sso and quarkus
    [#32](https://github.com/ansible-middleware/keycloak/pull/32)

## v1.0.4

## v1.0.3

### Major Changes

-   New role for installing sso >= 17.0.0 (quarkus)
    [#29](https://github.com/ansible-middleware/keycloak/pull/29)

### Minor Changes

-   Add `sso_config_override_template` parameter for passing a custom
    xml config template
    [#30](https://github.com/ansible-middleware/keycloak/pull/30)

### Bugfixes

-   Make sure systemd unit starts with selected java JVM
    [#31](https://github.com/ansible-middleware/keycloak/pull/31)

## v1.0.2

### Minor Changes

-   Make `sso_admin_password` a default with assert (was: role variable)
    [#26](https://github.com/ansible-middleware/keycloak/pull/26)
-   Simplify dependency install logic and reduce play execution time
    [#19](https://github.com/ansible-middleware/keycloak/pull/19)

### Bugfixes

-   Set `sso_frontend_url` default according to other defaults
    [#25](https://github.com/ansible-middleware/keycloak/pull/25)

## v1.0.1

### Release Summary

Minor enhancements, bug and documentation fixes.

### Major Changes

-   Apply latest cumulative patch of RH-SSO automatically when new
    parameter `sso_rhsso_apply_patches` is `true`
    [#18](https://github.com/ansible-middleware/keycloak/pull/18)

### Minor Changes

-   Clustered installs now perform database initialization on first node
    to avoid locking issues
    [#17](https://github.com/ansible-middleware/keycloak/pull/17)

## v1.0.0

### Release Summary

This is the first stable release of the `redhat.sso` collection.
